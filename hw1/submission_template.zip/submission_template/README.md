## Counting Problem
There are some duplicated comments in the dataset because some users posted exactly same content at different time which results in two unique rows with different "publish_date" value but exactly same content. Therefore, the fraction 0.022490628904623073 (rounded to 0.022) is higher than the fraction after removing the duplicate, 0.01976035316375867, it's an overestimate. 
