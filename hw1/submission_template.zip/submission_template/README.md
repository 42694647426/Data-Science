## Counting Problem
There are some duplicated comments in the dataset because some users posted exactly same content at different time which results in two unique rows with different "publish_date" value but exactly same content. Therefore I deleted the dulicated rows and recompute the proportion of comments mentioning "Trump".
